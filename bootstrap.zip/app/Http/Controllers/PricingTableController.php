<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PricingTableController extends Controller
{
    //
}
